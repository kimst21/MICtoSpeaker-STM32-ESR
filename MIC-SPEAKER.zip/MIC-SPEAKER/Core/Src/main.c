/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * - STM32 마이크로컨트롤러를 사용하여 I2S 인터페이스를 통해 오디오 데이터를 처리하는 프로그램입니다.
  * - DMA를 활용하여 MIC에서 데이터를 수신(I2S5)하고, MAX98357을 통해 데이터를 송신(I2S3)합니다.
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"        // STM32 시스템 초기화 관련 헤더
#include "dma.h"         // DMA 초기화 및 제어 관련 헤더
#include "i2s.h"         // I2S 인터페이스 초기화 및 제어 헤더
#include "gpio.h"        // GPIO 초기화 관련 헤더

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
// 추가 라이브러리 포함 가능
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
// 사용자 정의 데이터 타입 선언 가능
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
// 사용자 정의 매크로 정의 가능
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
// 사용자 정의 매크로 선언 가능
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
uint16_t toReceive; // MIC에서 수신한 데이터를 저장할 변수
uint16_t toWrite;   // MAX98357로 송신할 데이터를 저장할 변수
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);          // 시스템 클럭 설정 함수
void PeriphCommonClock_Config(void);    // 공통 주변 클럭 설정 함수

/* USER CODE BEGIN PFP */
// 사용자 정의 함수 프로토타입 선언 가능
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/**
  * @brief I2S DMA 수신 완료 콜백 함수
  * @param hi2s : 데이터 수신이 완료된 I2S 핸들러
  */
void HAL_I2S_RxCpltCallback(I2S_HandleTypeDef *hi2s)
{
    toWrite = toReceive;                                   // 수신 데이터를 송신 데이터로 복사
    HAL_I2S_Transmit_DMA(&hi2s3, &toWrite, 1);            // 송신 데이터 전송 (MAX98357)
    HAL_I2S_Receive_DMA(hi2s, &toReceive, 1);            // MIC에서 데이터 재수신 시작
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  // 프로그램 시작 시 사용자 정의 초기 설정 가능
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  HAL_Init();                      // HAL 라이브러리 초기화

  /* Configure the system clock */
  SystemClock_Config();            // 시스템 클럭 설정

  /* Configure the peripherals common clocks */
  PeriphCommonClock_Config();      // 공통 주변 클럭 설정

  /* Initialize all configured peripherals */
  MX_GPIO_Init();                  // GPIO 초기화
  MX_DMA_Init();                   // DMA 초기화
  MX_I2S5_Init();                  // I2S5 초기화 (MIC)
  MX_I2S3_Init();                  // I2S3 초기화 (MAX98357)

  /* USER CODE BEGIN 2 */
  HAL_I2S_Receive_DMA(&hi2s5, &toReceive, 1); // I2S5를 통해 MIC에서 DMA 수신 시작
  /* USER CODE END 2 */

  /* Infinite loop */
  while (1)
  {
    /* USER CODE END WHILE */
    // 무한 루프: 주요 작업은 DMA와 인터럽트에서 처리
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Initializes the peripherals clock
  */
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 192;
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 16;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
